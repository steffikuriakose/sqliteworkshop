.open data/sqlite-sakila.db
.output
.header ON
.mode qbox
.tables
.schema actor
